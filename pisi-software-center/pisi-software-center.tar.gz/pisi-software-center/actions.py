#!/usr/bin/python
# -*- coding: utf-8 -*-

from pisi.actionsapi import shelltools, get, pisitools
import os

def build():
    # Cargo'nun sistemdeki HOME dizinine dokunmaması ve her şeyi /var/pisi altındaki 
    # çalışma alanında tutması için CARGO_HOME değişkenini tanımlıyoruz.
    shelltools.export("CARGO_HOME", os.path.join(get.workDir(), ".cargo"))

    # Makefile'daki build kuralını çalıştırır (cargo build --release)
    shelltools.system("make")

def install():
    # Makefile'daki install kuralını kullanarak DESTDIR içine kurar
    shelltools.system("make DESTDIR=%s install" % get.installDir())